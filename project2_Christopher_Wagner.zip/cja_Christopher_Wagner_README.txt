a)
Christopher Wagner

b)
My project entitled "Hardcore Parkour" is a 2D platformer in the style
of the Mario franchise's first few console instalments.

Upon running the "Game" class in IntelliJ, a JFrame will apppear,
containing a JMenuBar with two Menus, each containing two and one 
JMenuItem respectively (each is described below). Below the menu bar
is a JLabel displayng "Points:" directly beside a JTextArea that
displays the number of points the player has. Below this display, 
there is a GamePanel, which extends JPanel, displaying the primary
workings of the game engine.

c)
At the Title screen:

	At the title screen, press <enter> to begin a new game.

	Your character, Ty the surprisingly athletic hipster,
	will be placed in level one for you.


During gameplay:

	Use the left (<-), right (->), and up(^) arrow keys to
	control Ty. The <space> bar and up(^) arrow can both
	be used to jump.

	Jump from rooftop to rooftop to reach the finish line at
	end (right side) of the level. 


	Collect coins along the way to gain extra points. Each
	Coin is worth 50 points.

	Careful, though. If you let Ty fall between buildings,
	you will lose 500 points and be sent back to the
	beginning of the level.

	Once Ty crosses the finish line, the level is over.
	Press <enter> to recieve 1000 additional points and
	advance to the next level.

	Anti-Gravity vortexes (three upward-facing green arrows
	on the screen) are pockets of reversed gravity. Move
	Ty into them and he will float upward.

The Menu Bar:

	Game->

	New Game:	
	Starting a new game will take you back to the title
	screen and clear your points.

	End Game:
	Ending the game will conclude your game and display
	your points on the screen. If you wish to play
	again, select 'New Game' in the Game menu.

	
	Help->

	Instructions:
	These instructions are displayed with some variation in a 
	separate JFrame containing a scollable pane.

d)
My project is the coolest because it is very visual. All the graphics exculding
the background image were created by hand in MS paint by me (with some
reference images cited below for inspiration). The background was derived 
from an existing photograph(cited below) by changing the resolution quality. 
The majority of the game engine is my own design (some reference cited below for
a launch point). Also, all the audio in the game is my voice.

e)Citations:

Game Engine References:

http://www.java-gaming.org/index.php?topic=24220.0

https://www.youtube.com/watch?v=9dzhgsVaiSo (and subsequent videos)

http://stackoverflow.com/questions/22139886/jbox2d-issensor-for-npc-collision

http://www.tonypa.pri.ee/tbw/tut05.html

Image Reference:

http://previewcf.turbosquid.com/Preview/Content_2009_07_26__10_56_46/skyl3.jpg7FA62F1D-8DD1-47A8-9107D8A420ACB457.jpgLarger.jpg

http://www.online-image-editor.com/help/transparency

Google Image searches: "mario 8 bit sprite", "8 bit coin"

Sound reference:

http://stackoverflow.com/questions/10570345/java-getaudioinputstream-symbol-not-found

http://stackoverflow.com/questions/18471333/java-trouble-using-audio-clips
	
	




