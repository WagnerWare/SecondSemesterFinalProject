package Main;

import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.swing.*;
import java.applet.AudioClip;
import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.net.URL;

/**
 * Created by Chris on 3/30/14.
 */
public class GamePanel extends JPanel implements Runnable, KeyListener{

    protected static boolean running, paused;
    private int FPS = 45;
    private long nanoPerFrame = 1000/FPS;

    protected Thread thread;

    protected static Clip ding;

    private static BufferedImage image;
    protected static Graphics2D g;
    protected static int level = 0, tileSize = 60, playerRad = 20, drawnRows = 8, drawnCols = 10;

    private TitleScreen menu = new TitleScreen();
    protected static Level1 lev1 = new Level1();
    protected static Level2 lev2 = new Level2();

    protected static double maxSpeed=3.0;


    public GamePanel(){
        super();
        setPreferredSize(new Dimension(640, 480));
        setFocusable(true);
        requestFocus();
    }

    public void addNotify() {
        super.addNotify();
        if(thread == null) {
            thread = new Thread(this);
            addKeyListener(this);
            thread.start();
        }
    }


    protected static void load() {
        image = new BufferedImage(640, 480, BufferedImage.TYPE_INT_RGB);
        g = (Graphics2D) image.getGraphics();

        running = true;

        //load audio
        ding = null;

        try{
            AudioInputStream audioIn = AudioSystem.getAudioInputStream(new File("../Files/BaDing.wav"));
            ding = AudioSystem.getClip();
            ding.open(audioIn);
        }
        catch( Exception e ){
            System.out.println("Error: " + e.getMessage());
        }
    }


    public void run() {
        load();

        long start;
        long elapsed;
        long wait;

        // game loop
        while(running) {

            if(paused)
                continue;

            start = System.nanoTime();

            requestFocus();
            update();
            draw();

            elapsed = System.nanoTime() - start;

            wait = nanoPerFrame - elapsed / 1000000;
            if(wait < 0) wait = 5;//may be unnecessary

            try {
                Thread.sleep(wait);

            }
            catch(Exception e) {
                System.out.println("Error: " + e.getMessage());
            }
        }
    }

    private void update() {//use a switch statements and the level int
        switch (level){
            case(0):
                menu.update();
                break;
            case(1):
                lev1.update();
                break;
            case(2):
                lev2.update();
                break;
            case(3):
                break;
        }
    }

    private void draw() {
        switch (level){
        case(0):
            menu.draw(g);
            break;
        case(1):
            lev1.draw(g);
            break;
        case(2):
            lev2.draw(g);
            break;
        case(3):

            g.drawImage(lev1.background, 0, 0, null);
            g.setColor(new Color(255, 200, 0));
            g.setFont(new Font("Impact", Font.BOLD, 50));
            g.drawString("Good Game!", 190, 230);
            g.setFont(new Font("Impact", Font.PLAIN, 30));
            g.drawString("You scored " + Game.points + " points!", 185, 275);
            break;
    }
        Graphics g2 = this.getGraphics();
        g2.drawImage(image, 0, 0, 640, 480, null);
        g2.dispose();
    }


    public void keyPressed(KeyEvent ke) {
        switch (level){
            case(0):
                menu.keyPressed(ke.getKeyCode());
                break;
            case(1):
                lev1.keyPressed(ke.getKeyCode());
                break;
            case(2):
                lev2.keyPressed(ke.getKeyCode());
                break;
            case(3): 
                break;
        }
    }
    public void keyReleased(KeyEvent ke) {
        switch (level){
            case(0):
                menu.keyReleased(ke.getKeyCode());
                break;
            case(1):
                lev1.keyReleased(ke.getKeyCode());
                break;
            case(2):
                lev2.keyReleased(ke.getKeyCode());
                break;
            case(3):
                break;
        };
    }
    public void keyTyped(KeyEvent key) {}


    protected static void endGame(){
        level=3;
    }

    protected static void startMusic(){
        new Thread(new Runnable(){
            public void run(){
                Clip song;
                try{
                    AudioInputStream audioIn = AudioSystem.getAudioInputStream(new File("../Files/ProjectSong.wav"));
                    song = AudioSystem.getClip();
                    song.open(audioIn);
                    song.loop(Clip.LOOP_CONTINUOUSLY);
                    song.start();
                }
                catch( Exception e ){
                    System.out.println("Error: " + e.getMessage());
                }
            }
        }).start();
    }

    /*
    public void play()
    {
        new Thread(new Runnable(){
            public void run(){
                Clip ding;
                try{
                    AudioInputStream audioIn = AudioSystem.getAudioInputStream(new File("../Images/BaDing.wav"));
                    ding = AudioSystem.getClip();
                    ding.open(audioIn);
                    ding.start();
                }
                catch( Exception e ){
                    System.out.println("Error: " + e.getMessage());
                }
            }
        }).start();
    }
     */
}
