package Main;

import javax.imageio.ImageIO;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.image.BufferedImage;
import java.io.File;

/**
 * Created by Chris on 4/5/14.
 */
public class TitleScreen{

    protected BufferedImage image = new BufferedImage(640,480,BufferedImage.TYPE_INT_RGB);

    public TitleScreen(){
        try{
            image = ImageIO.read(new File("../Files/GameBackground2.jpg")) ;
        }
        catch(Exception e){
            System.out.println("Error: " + e.getMessage());
        }
    }

    public void update(){}

    public void draw(Graphics2D g) {
        g.drawImage(image,0,0, null);
        g.setColor(new Color(255, 200, 0));
        g.setFont(new Font("Impact", Font.BOLD, 50));
        g.drawString("Hardcore Parkour", 110, 230);
        g.setFont(new Font("Impact", Font.PLAIN, 30));
        g.drawString("Press <enter> to begin", 170, 275);
    }

    public void keyPressed(int code) {
        if(code == KeyEvent.VK_ENTER){
            GamePanel.level++;
            GamePanel.startMusic();
        }
    }
    public void keyReleased (int code) {}
}
