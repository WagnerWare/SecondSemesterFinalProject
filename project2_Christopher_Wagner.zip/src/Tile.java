package Main;

import java.awt.image.BufferedImage;

/**
 * Created by Chris on 4/11/14.
 */
public class Tile {

    protected boolean obstacle;
    protected BufferedImage image;

    public Tile(BufferedImage i, boolean o) {
        image = i;
        obstacle = o;
    }
}
