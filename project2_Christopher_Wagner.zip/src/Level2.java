package Main;

import javax.imageio.ImageIO;
import javax.sound.sampled.Clip;
import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileReader;
import java.util.Scanner;

/**
 * Created by Chris on 4/13/14.
 */
public class Level2 {
    protected static double x;
    protected static double y;
    protected static double dx;
    protected static double dy;

    private boolean runLeft=false,
            runRight=false,
            jumping=false,
            airborn=false,
            facingRight=true;
    protected static boolean complete=false;

    private Scanner inFile;
    private int[][] gridMap;
    private int rows, cols;
    private int playerFrame, runFrameNum=0, frameDelay=0;


    // tileset
    private BufferedImage tileset, background, spriteset;
    private int tSetWidth, sSetWidth;
    private Tile[][] tiles;
    private BufferedImage[] sprites;

    // drawing
    private int rowOffset;
    private int colOffset;

    //player
    protected static double playX;
    protected static double playY;


    public Level2(){
        playX=6*GamePanel.tileSize+GamePanel.playerRad;
        playY=28*GamePanel.tileSize + GamePanel.playerRad;
        x=playX-340;
        y=playY-260;
        dy=dx=0;
        load();
    }

    protected void load() {

        //load background
        try{
            background = ImageIO.read(new File("../Files/GameBackground2.jpg")) ;
        }
        catch(Exception e){
            System.out.println("Error: " + e.getMessage());
        }

        //load the map data
        try{
            inFile = new Scanner(new FileReader("../Files/Level2.txt"));

            rows = inFile.nextInt();
            cols = inFile.nextInt();

            gridMap = new int[rows][cols];

            for(int i=0; i<rows; ++i){
                for(int j=0; j<cols; ++j){
                    gridMap[i][j] = inFile.nextInt();
                }
            }
        }
        catch(Exception e){
            System.out.println("Error: " + e.getMessage());
        }

        //load the map tiles
        try{
            tileset = ImageIO.read(new File("../Files/Level1Set.png"));
            tSetWidth = tileset.getWidth() / GamePanel.tileSize;
            tiles = new Tile[2][tSetWidth];

            BufferedImage current;
            for(int i=0; i < tSetWidth; ++i) {
                //first row image
                current = tileset.getSubimage(i * GamePanel.tileSize, 0, GamePanel.tileSize, GamePanel.tileSize);
                tiles[0][i] = new Tile(current, true);//these images are obstacles

                //second row image
                current = tileset.getSubimage(i * GamePanel.tileSize, GamePanel.tileSize,GamePanel.tileSize, GamePanel.tileSize);
                tiles[1][i] = new Tile(current, false); // these images are not obstacles
            }
        }
        catch(Exception e){
            System.out.println("Error: " + e.getMessage());
        }

        //load player sprites
        try{
            spriteset = ImageIO.read(new File("../Files/PlayerSprites.png"));
            sSetWidth = spriteset.getWidth() / (GamePanel.playerRad*2);
            sprites = new BufferedImage[sSetWidth];

            //Image current;
            for(int i=0; i < sSetWidth; ++i) {
                sprites[i] = spriteset.getSubimage(i * 2 * GamePanel.playerRad, 0, 2 * GamePanel.playerRad, 2 * GamePanel.playerRad);
            }

        }
        catch(Exception e){
            System.out.println("Error: " + e.getMessage());
        }
        playerFrame=0;
    }

    public void update() {
        //physics
        if(dx<GamePanel.maxSpeed && dx>-GamePanel.maxSpeed)
            dx+=runLeft?(-0.2):runRight?0.2:0;

        //look above
        int gMapNum = getGridMapNum('a');
        int tCol = ((gMapNum-1)%tSetWidth);
        int tRow = (gMapNum>tSetWidth)?1:0;
        if((tCol!=(-1))&&(tiles[tRow][tCol].obstacle)&&(dy<0)){//check collision above ('a')
            dy=0;
            dx-=dx>0?0.1:dx<0?(-0.1):0;//kinetic friction
            dx=((dx<0.1)&&(dx>-0.1))?0:dx;//static friction
        }

        //check below
        gMapNum = getGridMapNum('b');
        tCol = ((gMapNum-1) % tSetWidth);
        tRow = (gMapNum> tSetWidth) ? 1 : 0;
        if((tCol==(-1))||(!(tiles[tRow][tCol].obstacle)||jumping)){//check collision below ('b')
            dy+=0.133;//gravity
        }else{
            airborn=false;
            dy=0;
            dx-=dx>0?0.1:dx<0?(-0.1):0;
            dx=((dx<0.1)&&(dx>-0.1))?0:dx;
        }

        //look left
        gMapNum = getGridMapNum('l');
        tCol = ((gMapNum-1) % tSetWidth);
        tRow = (gMapNum> tSetWidth) ? 1 : 0;

        if((tCol!=(-1))&&(tiles[tRow][tCol].obstacle)&&(dx<0)){//check collision to the left ('l')
            dx=0;
        }

        //look right
        gMapNum = getGridMapNum('r');
        tCol = ((gMapNum-1) % tSetWidth);
        tRow = (gMapNum> tSetWidth) ? 1 : 0;

        if((tCol!=(-1))&&(tiles[tRow][tCol].obstacle)&&(dx>0)){//check collision to the right ('r')
            dx=0;
        }

        if(getGridMapNum('x')==25){//check if the player has reached the finish zone
            complete=true;
        }

        //anti-gravity vortex
        gMapNum = getGridMapNum('x');
        if(gMapNum == 26){
            dy-=0.183;
        }

        //anti-embedding
        gMapNum = getGridMapNum('s');
        tCol = ((gMapNum-1) % tSetWidth);
        tRow = (gMapNum> tSetWidth) ? 1 : 0;
        if(!((tCol==(-1))||(!(tiles[tRow][tCol].obstacle)))){
            --y;
            --playY;
        }

        x+=dx;
        y+=dy;
        playX+=dx;
        playY+=dy;

        handleDeath();

        handleCoinCollision();

        if((!runLeft)&&(!runRight)){
            determinePlayerFrame();
        }else if(frameDelay==8){
            determinePlayerFrame();
            frameDelay=0;
        }
        else
            ++frameDelay;

        jumping=false;

        colOffset = (int)((playX-320) / GamePanel.tileSize);
        rowOffset = (int)((playY-240) / GamePanel.tileSize);
    }

    public void draw(Graphics2D g) {
        //draw background
        g.drawImage(background, 0, 0, null);

        // draw tiles on screen
        for(int i=rowOffset; i<=(rowOffset+GamePanel.drawnRows); ++i){
            if(i>=rows)
                break;

            for(int j=colOffset; j<=(colOffset+GamePanel.drawnCols); ++j){
                if(j>=cols)
                    break;

                if((gridMap[i][j] == 0)||(gridMap[i][j] == 25)){
                    continue;
                }

                int col = (((gridMap[i][j])-1) % tSetWidth);
                int row = (gridMap[i][j]> tSetWidth) ? 1 : 0;

                g.drawImage(tiles[row][col].image, (int)-x + j * GamePanel.tileSize, (int) -y + i * GamePanel.tileSize, null);
            }
        }
        drawPlayer(g);
        if(complete){
            g.setColor(new Color(255, 200, 0));
            g.setFont(new Font("Impact", Font.BOLD, 50));
            g.drawString("Level Complete", 110, 230);
            g.setFont(new Font("Impact", Font.PLAIN, 30));
            g.drawString("Press <enter> to continue", 170, 275);
        }
    }

    private void determinePlayerFrame(){
        playerFrame=facingRight?0:7;
        playerFrame+=airborn?6:0;
        if((runRight||runLeft)&&(!airborn)){
            switch(runFrameNum){
                case(0):
                    ++playerFrame;
                    ++runFrameNum;
                    break;
                case(1):
                    playerFrame+=2;
                    ++runFrameNum;
                    break;
                case(2):
                    playerFrame+=3;
                    ++runFrameNum;
                    break;
                case(3):
                    ++playerFrame;
                    ++runFrameNum;
                    break;
                case(4):
                    playerFrame+=4;
                    ++runFrameNum;
                    break;
                case(5):
                    playerFrame+=5;
                    runFrameNum=1;
                    break;
            }

        }
    }

    private void drawPlayer(Graphics2D g){
        g.drawImage(sprites[playerFrame], 320, 240, null);
    }

    public void keyPressed(int code) {
        if(((code == KeyEvent.VK_SPACE || code == KeyEvent.VK_UP)&&!airborn)&&(!complete)){
            jumping=true;
            airborn=true;
            dy-=6;
        }
        if((code == KeyEvent.VK_LEFT )&&(!complete)){
            runLeft=true;
            facingRight=false;
        }else if((code== KeyEvent.VK_RIGHT)&&(!complete)){
            runRight=true;
            facingRight=true;
        }
        if((code == KeyEvent.VK_ENTER)&&complete){
            Game.points+=1000;
            Game.pts.setText(String.valueOf(Game.points));
            GamePanel.level++;
        }
    }

    public void keyReleased(int code) {
        if(code == KeyEvent.VK_LEFT){
            runLeft=false;
            runFrameNum=0;
        }else if(code == KeyEvent.VK_RIGHT){
            runRight=false;
            runFrameNum=0;
        }
    }


    public int getGridMapNum(char c){
        switch(c){
            case('b'):
                return gridMap[((int)((playY+GamePanel.playerRad+1)/GamePanel.tileSize))][((int)playX/GamePanel.tileSize)];
            case('a'):
                return gridMap[((int)((playY-GamePanel.playerRad-1)/GamePanel.tileSize))][((int)playX/GamePanel.tileSize)];
            case('l'):
                return gridMap[((int)(playY/GamePanel.tileSize))][((int)((playX-GamePanel.playerRad-1)/GamePanel.tileSize))];
            case('r'):
                return gridMap[((int)(playY/GamePanel.tileSize))][((int)((playX+GamePanel.playerRad+1)/GamePanel.tileSize))];
            case('x'):
                return gridMap[((int)(playY/GamePanel.tileSize))][((int)(playX/GamePanel.tileSize))];
            case('s'):
                return gridMap[((int)((playY+GamePanel.playerRad)/GamePanel.tileSize))][((int)playX/GamePanel.tileSize)];
        }
        return 0;
    }

    protected void handleDeath(){
        int below=getGridMapNum('b');
        if(below==24){
            playX=6*GamePanel.tileSize+GamePanel.playerRad;
            playY=28*GamePanel.tileSize + GamePanel.playerRad;
            x=playX-340;
            y=playY-260;
            dy=dx=0;
            Game.points-=500;
            Game.pts.setText(String.valueOf(Game.points));
        }
    }

    public void play( Clip clip )
    {
        if(clip.isRunning()){
            clip.stop();
        }
        clip.setFramePosition(0);
        clip.start();
    }

    protected void handleCoinCollision(){
        int curr=getGridMapNum('x');

        if(!((curr>14)&&(curr<22)))//if the current tile has no coins
            return;

        double localX = playX%GamePanel.tileSize;
        double localY = playY%GamePanel.tileSize;

        double dist=Math.sqrt(((6 - localX) * (6 - localX)) + ((28 - localY) * (28 - localY)));//distance between player and coin 1 by pythagorean
        ;
        if(((dist)<=GamePanel.playerRad)&&((curr-14)>=4)){
            gridMap[((int)(playY/GamePanel.tileSize))][((int)(playX/GamePanel.tileSize))]-=4;//remove coin
            Game.points+=50;
            Game.pts.setText(String.valueOf(Game.points));
            play(GamePanel.ding);
            return;
        }


        dist=Math.sqrt(((38-localX)*(38-localX))+((28-localY)*(28-localY)));//distance between player and coin 2
        if(((dist)<=GamePanel.playerRad)&&((((curr-12)%4)==0)||(curr-14==3))){
            gridMap[((int)(playY/GamePanel.tileSize))][((int)(playX/GamePanel.tileSize))]-=2;
            Game.points+=50;
            Game.pts.setText(String.valueOf(Game.points));
            play(GamePanel.ding);
            return;
        }

        dist=Math.sqrt(((52-localX)*(52-localX))+((28-localY)*(28-localY)));//distance between player and coin 3
        if(((dist)<=GamePanel.playerRad)&&((curr%2)==1)){
            gridMap[((int)(playY/GamePanel.tileSize))][((int)(playX/GamePanel.tileSize))]-=1;
            Game.points+=50;
            Game.pts.setText(String.valueOf(Game.points));
            play(GamePanel.ding);
            return;
        }
    }
}
