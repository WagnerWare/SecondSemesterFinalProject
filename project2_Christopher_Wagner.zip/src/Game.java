package Main;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;

/**
 * Created by Chris on 3/30/14.
 */
public class Game extends JFrame implements ActionListener {

    private static final int WIDTH = 640;
    private static final int HEIGHT = 576;

    private JMenuBar toolBar;
    private JMenu game, help;
    private JMenuItem newGame, endGame, instructs;
    private GamePanel screen;
    protected JPanel ptsPanel;
    protected static JTextArea pts;
    protected static int points;

    public Game(){

        setTitle("Hardcore Parkour");

        toolBar = new JMenuBar();
        game = new JMenu("Game");
        help = new JMenu("Help");
        newGame = new JMenuItem("New Game");
        endGame = new JMenuItem("End Game");
        instructs = new JMenuItem("Instructions");

        newGame.addActionListener(this);
        endGame.addActionListener(this);
        instructs.addActionListener(this);

        game.add(newGame);
        game.add(endGame);
        help.add(instructs);

        toolBar.add(game);
        toolBar.add(help);

        Container pane = getContentPane();
        pane.setLayout(new BorderLayout());
        pane.add(toolBar, BorderLayout.BEFORE_FIRST_LINE);

        ptsPanel = new JPanel();
        pts = new JTextArea("0");
        pane.add(ptsPanel);
        ptsPanel.add(new JLabel("Points:"));
        ptsPanel.add(pts);

        screen = new GamePanel();
        pane.add(screen,BorderLayout.AFTER_LAST_LINE);


        pts.setEditable(false);
        pts.setBackground(new Color(237, 237, 237));

        //pack();
        setSize(WIDTH, HEIGHT);
        setVisible(true);
        setResizable(false);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        screen.run();
    }

    public static void main(String[] args){
        try{
            Game time = new Game();
        }
        catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    public void closeWindow(){Toolkit.getDefaultToolkit().getSystemEventQueue().postEvent(new WindowEvent(this, WindowEvent.WINDOW_CLOSING));}

    //EITHER CREATE A NEW CLASS FOR IT OR PUT MENU LISTERS HERE AND STUFF
    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource()== newGame){
            points=0;
            pts.setText(String.valueOf(points));
            GamePanel.level=0;
            GamePanel.load();
            Level1.playX=6*GamePanel.tileSize+GamePanel.playerRad;
            Level1.playY=11*GamePanel.tileSize + GamePanel.playerRad;
            Level1.x=Level1.playX-340;
            Level1.y=Level1.playY-260;
            Level1.dy=Level1.dx=0;
            Level1.complete=false;
            GamePanel.lev1.load();
            Level2.playX=6*GamePanel.tileSize+GamePanel.playerRad;
            Level2.playY=28*GamePanel.tileSize + GamePanel.playerRad;
            Level2.x=Level2.playX-340;
            Level2.y=Level2.playY-260;
            Level2.dy=Level2.dx=0;
            Level2.complete=false;
            GamePanel.lev2.load();
        }else if(e.getSource() == endGame){
            GamePanel.paused=false;
            GamePanel.endGame();
        }
        else if(e.getSource() == instructs){
            Instructions help = new Instructions("Instructions");
        }
    }

}
