package Main;

import javax.swing.*;
import java.awt.*;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.Scanner;

/**
 * Created by Chris on 4/19/14.
 */
public class Instructions extends JFrame{

    private final int WIDTH = 500;
    private final int HEIGHT= 500;

    private Scanner inFile;
    private JScrollPane content;
    private JTextArea text;

    public Instructions(String s){

        super(s);

        text = new JTextArea();
        text.setEditable(false);

        try {
            inFile = new Scanner(new FileReader("../Files/Instructions.txt"));
        } catch (FileNotFoundException e) {
            System.out.println("Error:" + e.getMessage());
        }

        while(inFile.hasNextLine()){
            String line = inFile.nextLine();
            text.append(line + "\n");
        }

        text.setCaretPosition(0);

        content  = new JScrollPane(text, ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS, ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);

        Container pane = getContentPane();
        pane.setLayout(new BorderLayout());

        pane.add(content);

        pack();

        setLocation(700, 0);
        setSize(HEIGHT, WIDTH);
        setVisible(true);
        setResizable(false);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE); //unpause and deiconifygame
    }
}
